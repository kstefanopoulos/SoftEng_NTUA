package ch2;

import org.springframework.data.repository.CrudRepository;

public interface AdministratorRepository extends CrudRepository<administrator, String>{

}
