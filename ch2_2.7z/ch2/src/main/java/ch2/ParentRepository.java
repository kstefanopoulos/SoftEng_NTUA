package ch2;

import org.springframework.data.repository.CrudRepository;

public interface ParentRepository extends CrudRepository<parent, String>{

}

