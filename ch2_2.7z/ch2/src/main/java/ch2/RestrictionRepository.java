package ch2;

import org.springframework.data.repository.CrudRepository;

public interface RestrictionRepository extends CrudRepository<restrictions, String>{

}
	
