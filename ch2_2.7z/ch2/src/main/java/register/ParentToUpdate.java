package register;

public class ParentToUpdate {

		  private String firstname ;
		  private String lastname ;
		  private String streetname;
		  private String town;
		  private int streetnumber;
		  private String postalcode;
		  private String phonenumber;
		  
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getStreetname() {
			return streetname;
		}
		public void setStreetname(String streetname) {
			this.streetname = streetname;
		}
		public String getTown() {
			return town;
		}
		public void setTown(String town) {
			this.town = town;
		}
		public int getStreetnumber() {
			return streetnumber;
		}
		public void setStreetnumber(int streetnumber) {
			this.streetnumber = streetnumber;
		}
		public String getPostalcode() {
			return postalcode;
		}
		public void setPostalcode(String postalcode) {
			this.postalcode = postalcode;
		}
		public String getPhonenumber() {
			return phonenumber;
		}
		public void setPhonenumber(String phonenumber) {
			this.phonenumber = phonenumber;
		}
		  
		 
		 
	}